import React from 'react'

interface Props {}

function Unauthorized(props: Props) {

    return (
        <h1>Авторизуйся</h1>
    )
}

export default Unauthorized
