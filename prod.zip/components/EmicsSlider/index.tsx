import React from 'react'
import s from 'emics-slider.module.scss'

interface Props {}

function EmicsSlider(props: Props) {

    return (
        <>
            {/* TODO: выделить слайдер с карточками в отдельный компонент */}
        </>
    )
}

export default EmicsSlider
