import React from 'react'

interface Props {}

function Loader(props: Props) {

    return (
        <h1>Loading</h1>
    )
}

export default Loader
