export const LOCALES = {
    ENGLISH: 'en-us',
    RUSSIAN: 'ru-ru'
}